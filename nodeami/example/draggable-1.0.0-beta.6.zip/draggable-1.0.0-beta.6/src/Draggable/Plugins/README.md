## Draggable plugins

These plugins are included by draggable by default

- [Announcement](Announcement)
- [Focusable](Focusable)
- [Mirror](Mirror)
- [Scrollable](Scrollable)
