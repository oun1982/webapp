import SwapAnimation, {defaultOptions} from './SwapAnimation';

export default SwapAnimation;
export {defaultOptions};
