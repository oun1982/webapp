import MouseSensor from './MouseSensor';

export default MouseSensor;
