import ForceTouchSensor from './ForceTouchSensor';

export default ForceTouchSensor;
