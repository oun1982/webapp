import Emitter from './Emitter';

export default Emitter;
